#include <avr/io.h>

int main(void) {
	unsigned char cnt;	
	return 1;
}
